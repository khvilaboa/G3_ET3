G3_ET3
======

Consiste en un sistema para la gestión de trabajos de alumnos en un ámbito universitario. Los actores del sistema son:
  * Alumnos, que podrán subir entregas en los trabajos que esten asignados. Además, podrá crear un portfolio donde se        muestren una lista de los trabajos ya realizados que quiera seleccionar (que podrá ser accesible a través de una URL     pública).
  * Profesores, que pueden crear trabajos y asignar alumnos a estos. Una vez subidas las entregas por parte de los           alumnos, tendrán la capacidad de corregir (de forma numérica y, opcionalmente, con observaciones) dichas entregas.
  * Administrador, que se encarga de la gestión de usuarios y asignaturas, pudiendo asignar profesores a asignaturas.

El sistema permitirá el registro de usuarios en la plataforma con permisos de alumno, correspondiendo al adminstrador dar privilegios de profesor a los usuarios que corresponda..
